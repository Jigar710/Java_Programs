//create a new file : if exists then delete and create a new file
import java.io.*;
class test
{
	public static void main(String ar[])throws Exception
	{
		File f = new File("temp.txt");
		if(f.exists()==true)
		{
			f.delete();
		}
		System.out.println("createNewFile : "+f.createNewFile());
	}
}
/*
createNewFile : can create a new file if file does not exists
on success returns true
on failure returns false
*/