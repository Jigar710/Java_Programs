//create a nested folder 
import java.io.*;
class test
{
	public static void main(String ar[])throws Exception
	{
		File f = new File("first/second");
		System.out.println("mkdir : "+f.mkdirs());
	}
}
/*
mkdirs : create a new folder / hierarchy
on success returns true
on failure returns false
*/