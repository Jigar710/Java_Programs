import java.io.*;
class test
{
	public static void main(String ar[])
	{
		File f = new File("methods.txt");
		//File f = new File("C:\\Users\\mahes\\OneDrive\\Desktop\\java_5pm");
		System.out.println("isFile : "+f.isFile());
		System.out.println("isDirectory : "+f.isDirectory());
		System.out.println("exists : "+f.exists());
		System.out.println("length : "+f.length());
		System.out.println("canRead: "+f.canRead());
		System.out.println("canWrite : "+f.canWrite());
		System.out.println("lastModified : "+f.lastModified());
	}
}