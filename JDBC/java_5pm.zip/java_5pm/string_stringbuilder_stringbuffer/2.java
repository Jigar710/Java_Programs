//String : non-mutuable
class test
{
	public static void main(String ar[])
	{
		//String a = new String("welcome");
		String a = "welcome";
		
		System.out.println(a.hashCode());
		
		a = a + "1";
		System.out.println(a.hashCode());
	}
}