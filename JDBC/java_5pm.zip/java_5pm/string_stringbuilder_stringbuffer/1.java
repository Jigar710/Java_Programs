/*
String
StringBuffer
StringBuilder
*/
class test
{
	public static void main(String ar[])
	{
		String a = new String("demo of String");
		StringBuffer b = new StringBuffer("demo of StringBuffer");
		StringBuilder c = new StringBuilder("demo of StringBuilder");
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);		
	}
}