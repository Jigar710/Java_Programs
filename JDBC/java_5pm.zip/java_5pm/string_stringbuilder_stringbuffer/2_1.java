//StringBuffer : mutuable
class test
{
	public static void main(String ar[])
	{
		StringBuffer a = new StringBuffer("welcome");
		
		
		System.out.println(a.hashCode());
		
		a = a.append("1");
		System.out.println(a.hashCode());
	}
}