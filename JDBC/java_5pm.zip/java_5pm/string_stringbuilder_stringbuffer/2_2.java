//StringBuilder : mutuable
class test
{
	public static void main(String ar[])
	{
		StringBuilder a = new StringBuilder("welcome");
				
		System.out.println(a.hashCode());
		
		a = a.append("1");
		System.out.println(a.hashCode());
	}
}