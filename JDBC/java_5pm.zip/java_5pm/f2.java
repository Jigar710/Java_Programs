import java.io.*;
class test
{
	public static void main(String ar[])throws Exception
	{
		File f = new File("first/temp.txt");
		System.out.println("createNewFile : "+f.createNewFile());
		System.out.println("getName : "+f.getName());
		System.out.println("getAbsolutePath : "+f.getAbsolutePath());
		System.out.println("getPath : "+f.getPath());
		System.out.println("getParent : "+f.getParent());
	}
}
/*
createNewFile : can create a new file if file does not exists
on success returns true
on failure returns false
*/