import java.io.*;
class test
{
	public static void main(String ar[])throws Exception
	{
		File f = new File("C:\\Users\\mahes\\OneDrive\\Desktop\\java_5pm");
		String []lst = f.list();
		for(String a : lst)
		{
			File temp = new File(a);
			if(temp.isFile())
				System.out.println(a+" : <FILE>"+" : "+temp.length());
			else
				System.out.println(a+" : <DIR>"+" : "+temp.length());
		}
	}
}
/*
createNewFile : can create a new file if file does not exists
on success returns true
on failure returns false
*/