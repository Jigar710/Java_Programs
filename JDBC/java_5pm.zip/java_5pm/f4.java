//create a new folder 
import java.io.*;
class test
{
	public static void main(String ar[])throws Exception
	{
		File f = new File("first");
		System.out.println("mkdir : "+f.mkdir());
	}
}
/*
mkdir : create a new folder : but parent folder must be exists
on success returns true
on failure returns false
*/