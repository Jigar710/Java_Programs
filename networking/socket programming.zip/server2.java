
import java.net.*;
import java.io.*;

class server2
{
	public static void main(String ar[])throws Exception
	{
		ServerSocket ss = new ServerSocket(1000);
		Socket s = ss.accept();
		
		OutputStream os = s.getOutputStream();
		os.write('A');
	}
}