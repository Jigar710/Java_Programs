import java.net.*;
import java.io.*;

class client2
{
	public static void main(String ar[])throws Exception
	{
		Socket s = new Socket("localhost",1000);
		InputStream is = s.getInputStream();
		
		System.out.println(is.available());
		System.out.println((char)is.read());
		System.out.println(is.available());
	}
}