import java.util.*;
import java.net.*;
import java.io.*;
class dataRec extends Thread
{
	InputStream is;
	DataInputStream dis;
	ArrayList<Socket> ar;
	
	dataRec(InputStream is,ArrayList<Socket> ar)
	{
		this.is = is;
		this.dis = new DataInputStream(is);
		this.ar = ar;
	}
	public void run()
	{
		while(true)
		{
			
			try
			{
				String msg = dis.readUTF();
				for(int i=0;i<ar.size();i++)
				{
					Socket s = ar.get(i);
					OutputStream os = s.getOutputStream();
					InputStream is = s.getInputStream();
					if(this.is == is)
					{
						continue;
					}
					DataOutputStream dos = new DataOutputStream(os);
					dos.writeUTF(msg);
					//dos.close();
				}
			}
			catch(Exception e)
			{
				System.out.println("client rec prob");
			}
		}
	}

}