import java.net.*;
import java.io.*;
import java.util.*;

class SenderThread1 extends Thread
{
	Scanner sc;
	Socket s[];
	SenderThread1(Socket s[])
	{
		sc = new Scanner(System.in);
		this.s = s;
	}
	void delete(int index)
	{
		for(int i=index;i<s.length-1;i++)
		{
			s[i] = s[i+1];
		}
	}
	public void run()
	{
		while(true)
		{
			String msg = sc.nextLine();
			for(int i=0;i<s.length;i++)
			{
				if(s[i]!=null)
				{
					try
					{
						OutputStream os = s[i].getOutputStream();
						DataOutputStream dos = new DataOutputStream(os);
						dos.writeUTF(msg);
					}
					catch(SocketException e)
					{
						delete(i);
					}			
					catch(Exception e)
					{
						System.out.println("SenderThread Error : "+e);
					}
				}
				
				else
				{
					break;
				}
			}			
		}
	}
}