import java.net.*;
import java.io.*;
import java.util.*;

class SenderThread extends Thread
{
	Scanner sc;
	Socket s[];
	SenderThread(Socket s[])
	{
		sc = new Scanner(System.in);
		this.s = s;
	}
	public void run()
	{
		while(true)
		{
			try
			{
				String msg = sc.nextLine();
				for(Socket temp : s)
				{
					if(temp!=null)
					{
						OutputStream os = temp.getOutputStream();
						DataOutputStream dos = new DataOutputStream(os);
						dos.writeUTF(msg);
					}
					else
					{
						break;
					}
				}
			}
			catch(Exception e)
			{
				System.out.println("SenderThread Error : "+e);
			}
		}
	}
}