import java.net.*;
import java.util.*;
import java.io.*;

class client
{
	public static void main(String ar[])throws Exception
	{
		Socket s = new Socket("localhost",1000);
		
		InputStream is = s.getInputStream();
		DataInputStream dis = new DataInputStream(is);
		
		while(true)
		{
			String msg = dis.readUTF();
			System.out.println(msg);
		}
	}
}