import java.io.*;
import java.net.*;
class AcceptorThread extends Thread
{
	int i;
	Socket s[];
	ServerSocket ss;
	AcceptorThread(Socket s[],ServerSocket ss)
	{
		this.s = s;
		this.ss = ss;
	}
	public void run()
	{
		while(true)
		{
			try
			{
				if(i<s.length)
				{
					s[i] = ss.accept();
					i++;
					//System.out.println("Client Connected : "+i);
				}
			}
			catch(Exception e)
			{
				System.out.println("AcceptorThread Error : "+e);
			}
		}
	}
}