import java.net.*;
import java.util.*;
import java.io.*;
class server
{
	public static void main(String ar[])throws Exception
	{
		Socket s[] = new Socket[10];
		ServerSocket ss = new ServerSocket(1000);
	
		AcceptorThread acceptor = new AcceptorThread(s,ss);
		acceptor.start();
		
		SenderThread1 send = new SenderThread1(s);
		send.start();
	}
}