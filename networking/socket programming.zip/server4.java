import java.net.*;
import java.io.*;
import java.util.*;

class server4
{
	public static void main(String ar[])
	{
		try
		{
			Scanner sc = new Scanner(System.in);
			
			ServerSocket ss = new ServerSocket(1000);
			Socket s = ss.accept();
			
			System.out.println("Enter msg : ");
			String msg = sc.nextLine();
									
			OutputStream os = s.getOutputStream();
			DataOutputStream dos = new DataOutputStream(os);
			
			dos.writeUTF(msg);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}