import java.net.*;
import java.io.*;
import java.util.*;

class server_broadcast
{
	public static void main(String ar[])
	{
		try
		{
			Scanner sc = new Scanner(System.in);
			
			ServerSocket ss = new ServerSocket(1000);
			Socket s1 = ss.accept();
			Socket s2 = ss.accept();			
			
			OutputStream os1 = s1.getOutputStream();
			DataOutputStream dos1 = new DataOutputStream(os1);
			
			OutputStream os2 = s2.getOutputStream();
			DataOutputStream dos2 = new DataOutputStream(os2);
			
			String msg = sc.nextLine();
			
			dos1.writeUTF(msg);
			dos2.writeUTF(msg);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}