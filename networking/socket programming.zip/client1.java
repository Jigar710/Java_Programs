import java.net.*;
import java.io.IOException;

class client1
{
	public static void main(String ar[])throws IOException
	{
		Socket s = new Socket("localhost",1000);
		System.out.println(s);
	}
}