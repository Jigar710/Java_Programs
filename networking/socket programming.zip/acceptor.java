import java.net.*;
import java.io.*;
import java.util.*;
class acceptor extends Thread
{
	ArrayList<Socket> ar;
	ServerSocket ss;
	
	acceptor(ServerSocket ss)
	{
		this.ss = ss;
		ar = new ArrayList<Socket>();
		
		//System.out.println("from const : "+ar.size());
	}
	public void run()
	{
		while(true)
		{
			try
			{
				Socket s = ss.accept();
				ar.add(s);
				dataRec rec = new
					dataRec(s.getInputStream(),ar);
				rec.start();
			//	System.out.println(ar.size());
			}
			catch(Exception e)
			{
				System.out.println("accept exception");
			}
		}
	}
}