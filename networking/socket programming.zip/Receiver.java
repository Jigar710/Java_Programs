import java.util.*;
import java.net.*;
import java.io.*;

class Receiver extends Thread
{
	DataInputStream dis;
	Receiver(DataInputStream dis)
	{
		this.dis = dis;
	}
	public void run()
	{
		while(true)
		{
			try
			{
				String msg = dis.readUTF();
				System.out.println(msg);
			}
			catch(Exception e)
			{
				System.out.println("client rec prob");
			}
		}
	}

}