import java.net.*;
import java.io.*;
import java.util.*;

class client_echo
{
	public static void main(String ar[])
	{
		try
		{
			Scanner sc = new Scanner(System.in);
		
			Socket s = new Socket("localhost",1000);
			
			OutputStream os = s.getOutputStream();
			DataOutputStream dos = new DataOutputStream(os);
			
			InputStream is = s.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			
			while(true)
			{
				String rec = dis.readUTF();	// read string from server
				System.out.println("Server : "+rec);
				if(rec.equalsIgnoreCase("exit"))
					break;
							
				String msg = sc.nextLine();
				dos.writeUTF(msg);	// write string to server
				
				if(msg.equalsIgnoreCase("exit"))
					break;
			}			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}