import java.net.*;
import java.io.*;

class client_broadcast
{
	public static void main(String ar[])
	{
		try
		{
			Socket s = new Socket("localhost",1000);
			
			InputStream is = s.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			
			String rec = dis.readUTF();	// read string from server
			System.out.println("Server : "+rec);						
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}