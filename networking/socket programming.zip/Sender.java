import java.util.*;
import java.net.*;
import java.io.*;
class Sender extends Thread
{
	DataOutputStream dos;
	Scanner sc;
	Sender(DataOutputStream dos)
	{
		this.dos = dos;
		sc = new Scanner(System.in);
	}
	public void run()
	{
		while(true)
		{
			try
			{
				String msg = sc.nextLine();
				dos.writeUTF(msg);
			}
			catch(Exception e)
			{
				System.out.println("client sender prob");
			}
		}
	}
}