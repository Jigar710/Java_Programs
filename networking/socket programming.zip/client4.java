import java.net.*;
import java.io.*;
class client4
{
	public static void main(String ar[])
	{
		try
		{
			Socket s = new Socket("localhost",1000);
			
			InputStream is = s.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			
			String msg = dis.readUTF();
			System.out.println(msg);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
