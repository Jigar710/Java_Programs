import java.net.*;
import java.io.*;
import java.util.*;

class server_echo
{
	public static void main(String ar[])
	{
		try
		{
			Scanner sc = new Scanner(System.in);
			
			ServerSocket ss = new ServerSocket(1000);
			Socket s = ss.accept();
			
			OutputStream os = s.getOutputStream();
			DataOutputStream dos = new DataOutputStream(os);
			
			InputStream is = s.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			
			while(true)
			{
				String msg = sc.nextLine();
				dos.writeUTF(msg);	//send string to client
				
				String rec = dis.readUTF();
				System.out.println("Client : "+rec);
				
				if(rec.equalsIgnoreCase("exit"))
					break;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}