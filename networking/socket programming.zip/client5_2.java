import java.net.*;
import java.io.*;
import java.util.*;

class client5_2
{
	public static void main(String ar[])
	{
		try
		{
			Socket s = new Socket("localhost",1000);
			
			InputStream is = s.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			
			OutputStream os = s.getOutputStream();
			DataOutputStream dos = new DataOutputStream(os);
						
			String msg2 = dis.readUTF();
			System.out.println(msg2);
			
			Scanner sc = new Scanner(System.in);
			String msg1 = sc.nextLine();
			dos.writeUTF(msg1);			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}