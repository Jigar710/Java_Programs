import java.net.*;
import java.io.*;
class mserver
{
	public static void main(String ar[])throws Exception
	{
		ServerSocket ss = new ServerSocket(1000);
		
		acceptor accept = new acceptor(ss);
		accept.start();
	}
}