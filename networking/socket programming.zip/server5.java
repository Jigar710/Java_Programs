import java.net.*;
import java.io.*;
import java.util.*;

class server5
{
	public static void main(String ar[])
	{
		try
		{
			Scanner sc = new Scanner(System.in);
			
			ServerSocket ss = new ServerSocket(1000);
			Socket s1 = ss.accept();
			Socket s2 = ss.accept();			
			
			InputStream is1 = s1.getInputStream();
			DataInputStream dis1 = new DataInputStream(is1);
			InputStream is2 = s2.getInputStream();
			DataInputStream dis2 = new DataInputStream(is2);
			
			OutputStream os1 = s1.getOutputStream();
			DataOutputStream dos1 = new DataOutputStream(os1);			
			OutputStream os2 = s2.getOutputStream();
			DataOutputStream dos2 = new DataOutputStream(os2);
			
			String msg = dis1.readUTF();//read data from first client
			dos2.writeUTF(msg);
			
			String msg1 = dis2.readUTF();
			dos1.writeUTF(msg1);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}