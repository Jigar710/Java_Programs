import java.net.*;
import java.io.IOException;

class server1
{
	public static void main(String ar[])throws IOException
	{
		ServerSocket ss = new ServerSocket(1000);
		
		Socket s1 = ss.accept();
		System.out.println(s1);//s1.toString();		
		
		Socket s2 = ss.accept();
		System.out.println(s2);//s2.toString();
	}
}