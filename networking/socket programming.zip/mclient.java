import java.net.*;
import java.io.*;
class mclient
{
	public static void main(String ar[]) throws Exception
	{
		Socket s = new Socket("localhost",1000);
		
		OutputStream os = s.getOutputStream();
		InputStream is = s.getInputStream();
		
		Sender send = new Sender(new DataOutputStream(os));
		Receiver rec = new Receiver(new DataInputStream(is));
		
		send.start();
		rec.start();
	}
}		