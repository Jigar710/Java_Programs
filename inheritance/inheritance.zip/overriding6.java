/*
	can we access the private member 
	using super keywork in sub class
	no allowed bcoz scope opf the private is upto class.
*/

class first
{
	void disp()
	{
		System.out.println("this is super disp");
	}
	private void disp1()
	{
		System.out.println("this is super disp1");
	}
}
class sec extends first
{
	void disp()
	{
		System.out.println("this is sub disp");
	}
	void show()
	{
		super.disp();		
		super.disp1();
	}
}
class ss
{
	public static void	main(String ar[])
	{
		sec z = new sec();
		z.show();
		z.disp();	
		sec y = new sec();
		y.disp();	
	}
}