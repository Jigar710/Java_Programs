//final method : use to stop the overriding of the method
class first
{
	final void disp1()
	{
		System.out.println("this is super class method");
	}
}
class sec extends first
{
	void disp()
	{
		System.out.println("this is sub class method");
	}
}
class ss
{
	public static void main(String ar[])
	{
		sec z = new sec();
		z.disp();
		z.disp1();
	}
}