class demo
{
	int a = 45;
	demo(){}
	void disp()
	{
		System.out.println(a);
	}	
}
class ss
{
	public static void main(String ar[])
	{
		demo z = new demo();
		z.disp();
	}
}