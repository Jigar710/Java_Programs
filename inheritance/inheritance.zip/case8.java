//no const in base class and para const in derived
class base
{	
}
class derived extends base
{
	int a;
	derived(int p)
	{
		super();//optional
		a = p;
		System.out.println("para of derived : "+a);		
	}
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived(10);
	}
}