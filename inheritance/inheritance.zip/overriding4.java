/*
	to remove the effect of method overriding 
	"super" keyword is used.
	
	"super" keyword must be used within the 
	subclass only.
*/

class first
{
	void disp()
	{
		System.out.println("this is super disp");
	}
}
class sec extends first
{
	void disp()
	{
		System.out.println("this is sub disp");
	}
	void show()
	{
		super.disp();		
	}
}
class ss
{
	public static void	main(String ar[])
	{
		sec z = new sec();
		z.show();
		z.disp();	
		sec y = new sec();
		y.disp();	
	}
}