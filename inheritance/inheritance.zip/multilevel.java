class first{
	first()
	{
		System.out.println("def of first class");
	}
}
class sec extends first{
	sec()
	{
		System.out.println("def of sec class");
	}
}
class third extends sec{
	third()
	{
		System.out.println("def of third class");
	}
}
class demo
{
	public static void main(String ar[])
	{
		third z = new third();
	}
}