//can we override the private data members
class first
{
	int a = 10;
}
class sec extends first
{	
	int a = 45;
	void disp()
	{
		System.out.println(a);
		System.out.println(super.a);		
	}
}
class ss
{
	public static void	main(String ar[])
	{
		sec z = new sec();
		z.disp();
	}
}