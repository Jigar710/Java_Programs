//para in base class and def in derived
class base
{
	int a;
	base(int p)
	{
		a = p;
		System.out.println("para of parent : "+a);
	}
}
class derived extends base
{
	int b;
	derived(int q)
	{	
		super(10);
		b = q;
		System.out.println("para of derived : "+b);
	}
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived(45);
	}
}