/*
============================================================
				final method as a static method

=============================================================
*/
class first
{
	static final void disp()
	{
		System.out.println("1");
	}
}
class ss
{
	static public void main(String ar[])
	{
		first.disp();
	}
}