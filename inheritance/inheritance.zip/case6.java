//def const in base class and no const in derived
class base
{
	base()
	{
		System.out.println("def of base");		
	}
}
class derived extends base
{
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived();
	}
}