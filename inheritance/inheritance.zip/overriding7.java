//can we override the private data members

class first
{
	void disp()
	{
		System.out.println("this is super disp");
	}	
}
class sec extends first
{
	public void disp()
	{
		System.out.println("this is sub disp");
	}	
}
class ss
{
	public static void	main(String ar[])
	{
		sec z = new sec();
		z.disp();	
	}
}