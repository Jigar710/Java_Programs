//can we create the object of the final class
	//yes
final class first
{
	
}
class ss
{
	public static void main(String ar[])
	{
		first z = new first();	
	}
}