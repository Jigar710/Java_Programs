//para in base class and def in derived
class base
{
	int a;
	base(int p)
	{
		a = p;
		System.out.println("para of parent : "+a);
	}
}
class derived extends base
{
	derived()
	{	
		super(10);
		System.out.println("def of derived");
	}
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived();
	}
}