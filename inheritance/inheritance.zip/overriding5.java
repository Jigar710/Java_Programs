/*
	using super keyword we can access no overridden
	method also.
*/

class first
{
	void disp()
	{
		System.out.println("this is super disp");
	}
	void disp1()
	{
		System.out.println("this is super disp1");
	}
}
class sec extends first
{
	void disp()
	{
		System.out.println("this is sub disp");
	}
	void show()
	{
		super.disp();		
		super.disp1();
	}
}
class ss
{
	public static void	main(String ar[])
	{
		sec z = new sec();
		z.show();
		z.disp();	
		sec y = new sec();
		y.disp();	
	}
}