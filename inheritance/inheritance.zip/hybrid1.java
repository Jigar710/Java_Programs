class first{
	first()
	{
		System.out.println("def of first class");
	}
}
class sec extends first{
	sec()
	{
		System.out.println("def of sec class");
	}
}
class third extends first{
	third()
	{
		System.out.println("def of third class");
	}
}
class fourth extends third {
	fourth()
	{
		System.out.println("def of fourth class");
	}
}
class demo
{
	public static void main(String ar[])
	{
		sec y = new sec();
		System.out.println();
		
		third z = new third();
		System.out.println();
		
		fourth x = new fourth();
		System.out.println();
	}
}