//no const in base class and def in derived
class base
{
}
class derived extends base
{
	derived()
	{	
		System.out.println("def of derived ");
	}
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived();
	}
}