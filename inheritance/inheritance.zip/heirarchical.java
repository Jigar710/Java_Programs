class first{
	first()
	{
		System.out.println("def of first class");
	}
}
class sec extends first{
	sec()
	{
		System.out.println("def of sec class");
	}
}
class third extends first{
	third()
	{
		System.out.println("def of third class");
	}
}
class demo
{
	public static void main(String ar[])
	{
		sec y = new sec();
		third z = new third();
	}
}