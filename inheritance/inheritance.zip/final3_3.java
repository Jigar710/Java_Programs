/*
============================================================
				final methods in final class
it is useless
bcoz final keyword with the method is used to stop the
method overriding 
but if the class is final, then user can not inherit the 
class 
so can not override the method of the final class
so no need to declare the method as final.
=============================================================
*/
final class first
{
	void disp()
	{
		System.out.println("1");
	}
	final void disp1()
	{
		System.out.println("2");
	}
}
class ss
{
	public static void main(String ar[])
	{
		first z = new first();	
		z.disp();
		z.disp1();
	}
}