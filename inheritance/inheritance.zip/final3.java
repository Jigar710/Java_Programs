//final class : use to stop the inheritance of the class
final class first
{}
class sec extends first
{}
class ss
{
	public static void main(String ar[])
	{
		sec z = new sec();	
	}
}