//default in base class and para in derived
class base
{
	base()
	{
		System.out.println("def of parent");
	}
}
class derived extends base
{
	int a;
	derived(int p)
	{
		super();//optional
		a = p;
		System.out.println("para of derived : "+a);
	}
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived(100);
	}
}