//can we create the object of the final class
	//yes
final class first
{
	void disp()
	{
		System.out.println("1");
	}
}
class ss
{
	public static void main(String ar[])
	{
		first z = new first();	
		z.disp();
	}
}