class base
{
	base()
	{
		System.out.println("def of parent");
	}
}
class derived extends base
{
	derived()
	{
		super();//optional
		System.out.println("def of derived");
	}
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived();
	}
}