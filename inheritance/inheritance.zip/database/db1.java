import java.sql.*;
class db_demo
{
	public static void main(String ar[])
	{
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		
			Connection con;
			con = DriverManager.getConnection("jdbc:odbc:first");
			
			Statement st;
			st = con.createStatement();
			
			String q = "insert into emp values(3,'ccc','xxx')";
			
			int n = st.executeUpdate(q);
			System.out.println(n+" rows inserted");
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}