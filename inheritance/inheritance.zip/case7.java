//para const in base class and no const in derived
class base
{
	int a;
	base(int p)
	{
		a = p;
		System.out.println("para of base : "+a);		
	}
}
class derived extends base
{
}
class demo
{
	public static void main(String ar[])
	{
		derived a = new derived();
	}
}