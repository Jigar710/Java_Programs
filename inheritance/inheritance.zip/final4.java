/*
============================================================
				constructor as the final method
	can not declare the constructor as the final
	because final keyword with method is used to 
	stop the overriding 
	but if we are working with the constructor then 
	we can not override the constructor
	so no need to declare the constructor as the final.
	so it is not allowed.
=============================================================
*/
final class first
{
	final first()
	{
		System.out.println("1");
	}
}
class ss
{
	public static void main(String ar[])
	{
		first z = new first();			
	}
}