//final variable
class first
{
	void disp()
	{
		final int a;
		a = 70;
		//a = 9;
		System.out.println(a);
	}
}
class ss
{
	public static void main(String ar[])
	{
		first z = new first();
		z.disp();
	}
}